# ifndef _UTIL 
# define _UTIL

# include <iostream>
# include <vector>
using namespace std;

class Util{
	public:
		static int max(vector<int>);
};

# endif