# Membres du Binôme


| Nom     | Prénom  | Numéro d'étudiant |
| :-----: | :-----: | :-----: |
| Zobo Nomo| Franc| 71800466 |
| Abdelli| Mohand Said| 22124465 |